// nfa2dfa.h
#ifndef __NFA2DFA_H  // ��ֹ�ظ�����
#define __NFA2DFA_H

#include<cstring>
#include<iostream>
#include<fstream> 
#include<vector>
#include<set>
#include<queue>
#include<limits>
#include<map>
#include"../re2nfa/re2nfa.h"
using namespace std;

const int N = 100;

class DFA {
    public:
        // ״̬��ʶ��
        char index;
        // NFA״̬��
        int StateNum;
        // ��ʼ״̬�ͽ���״̬��
        int StartNum, StopNum;
        // ת���������ַ�����С
        int TransNum, LetterSize;
        // NFA�Ľ���״̬�Ϳ�ʼ״̬
        int StopState, StartState;
        // �ַ���
        set<char> LetterSet;
        // DFA��״̬��
        set<pair<char, set<int>>> stateSet;
        // ��������״̬����
        queue<set<int>> stateQueue;
        // ��ǰ״̬��
        set<int> currentState;
        // NFA��ת����
        vector<vector<pair<int, char>>> Edge;

        int newStateNum;          // �µ�DFA״̬��
        map<char, vector<pair<char, char>>> newEdge; // DFA��ת����
        set<char> startStates;    // DFA����ʼ״̬����
        set<char> acceptStates;   // DFA�Ľ���״̬����

        DFA(NFA nfa);
        // ����ת����
        void add(int a, int b, char signal);
        // NFAȷ����ΪDFA
        void deterDFA(int start);
        // ����״̬���Ƿ����
        int findState(set<int>);
        // ��ȡ����״̬�Ħűհ�
        set<int> getClosure(int cur);
        // ��ȡ״̬���Ħűհ�
        set<int> getClosure(set<int> cur);
        // ��ȡ״̬��ͨ��ĳ�ַ��ıհ�
        set<int> getClosure(set<int> cur, char signal);
        // ��ʾDFA��Ϣ
        void showDFA();
        // ����ַ����Ƿ�DFA����
        bool isValid(string input);
        // ����DFA��Graphviz DOT�ļ�
        void generateDot(const string& filename);
    protected:
};

DFA::DFA(NFA nfa) {
    // ��A��ʼ��ʶ״̬���
    index = 'A';
    newStateNum = 0; // ��״̬����ʼ��Ϊ0

    StateNum = nfa.stateNum; // ״̬��
    StartNum = 1;
    StartState = nfa.se.first;

    StopNum = 1;
    StopState = nfa.se.second;

    LetterSize = nfa.totalCharCount;
    LetterSet = nfa.charSet;

    Edge = nfa.graph;
}

// ���ӱ� a->b��ͨ���ַ� signal
void DFA::add(int a, int b, char signal) {
    Edge[a].push_back({b, signal});
}

// ����״̬�� cur �Ƿ��Ѵ���
int DFA::findState(set<int> cur) {
    for (auto k : stateSet) {
        if (k.second == cur)
            return 1;
    }
    return -1;
}

// ��ȡ״̬�� cur ͨ���ַ� signal �ıհ�
set<int> DFA::getClosure(set<int> cur, char signal) {
    set<int> newset;
    for (set<int>::iterator it = cur.begin(); it != cur.end(); it++) {
        for (auto k : Edge[*it]) {
            if (k.second == signal) {
                newset.insert(k.first);
            }
        }
    }
    return newset;
}

// ��ȡ״̬�� cur �Ħűհ�
set<int> DFA::getClosure(set<int> cur) {
    set<int> newset = cur;
    queue<int> q;
    for (set<int>::iterator it = cur.begin(); it != cur.end(); it++)
        q.push(*it);
    while (!q.empty()) {
        int t = q.front();
        q.pop();
        set<int> newele = getClosure(t);
        for (set<int>::iterator it = newele.begin(); it != newele.end(); it++) {
            q.push(*it);
            newset.insert(*it);
        }
    }
    return newset;
}

// ��ȡ����״̬ cur �Ħűհ�
set<int> DFA::getClosure(int cur) {
    set<int> newset;
    for (auto k : Edge[cur]) {
        if (k.second == '#') // '#' ��ʾ��
            newset.insert(k.first);
    }
    return newset;
}

// NFAȷ����ΪDFA
void DFA::deterDFA(int start) {
    // ����ʼ״̬���뵱ǰ״̬��
    currentState.insert(start);
    // ��ȡ��ʼ״̬�Ħűհ�
    currentState = getClosure(currentState);
    // ��״̬��ż�1
    newStateNum++;
    char curStateIndex = index; // ��ǰ״̬��ʶ��
    // ��ʼ״̬����״̬���ϲ����
    stateSet.insert({index, currentState});
    stateQueue.push(currentState);

    cout << "------------------------------------------------------------------------------------------------------------" << endl;
    cout << " I";
    for (const auto& it : LetterSet) {
        cout << "\t\t" << it;
    }
    cout << endl;
    cout << "------------------------------------------------------------------------------------------------------------" << endl;

    // ѭ�����������е�״̬��
    while (!stateQueue.empty()) {
        auto temp = stateQueue.front();
        for (auto k : stateSet) {
            if (k.second == temp) {
                cout << " " << k.first;
                curStateIndex = k.first;
                // ���״̬����������״̬��������Ϊ����״̬
                if (temp.count(StopState)) {
                    acceptStates.insert(k.first);
                } else {
                    startStates.insert(k.first);
                }
            }
        }
        stateQueue.pop();

        for (const auto& it : LetterSet) {
            currentState = temp;
            // ͨ���ַ���ȡ�հ�
            currentState = getClosure(temp, it);
            // ��ȡ������Ħűհ�
            currentState = getClosure(currentState);
            if (!currentState.empty()) {
                if (findState(currentState) == -1) {
                    stateSet.insert({++index, currentState});
                    stateQueue.push(currentState);
                    newStateNum++;
                }
                for (auto k : stateSet) {
                    if (k.second == currentState) {
                        cout << "\t\t" << k.first;
                        newEdge[curStateIndex].push_back({k.first, it});
                    }
                }
            } else {
                cout << "\t\t" << " ";
            }
        }
        cout << endl;
    }
    cout << "------------------------------------------------------------------------------------------------------------" << endl;
}

void DFA::showDFA() {
    cout << endl;
    cout << "New DFA States: " << newStateNum << endl;
    cout << "Start States: ";
    for (auto s : startStates) cout << s << ' ';
    cout << endl;
    cout << "Accept States: ";
    for (auto s : acceptStates) cout << s << ' ';
    cout << endl;
    cout << "Transitions:" << endl;
    for (auto& [from, transitions] : newEdge) {
        for (auto& [to, signal] : transitions) {
            cout << from << " --" << signal << "--> " << to << endl;
        }
    }
    for (auto k : stateSet) {
        char id = k.first;
        auto state = k.second;
        cout << id << " State: ";
        for (set<int>::iterator it = state.begin(); it != state.end(); it++)
            cout << *it << ' ';
        cout << endl;
    }
}

bool DFA::isValid(string input) {
    char currentState = 'A';
    if (!startStates.empty()) {
        currentState = *startStates.begin();
    }
    for (char c : input) {
        bool found = false;
        for (auto& transition : newEdge[currentState]) {
            if (transition.second == c) {
                currentState = transition.first;
                found = true;
                break;
            }
        }
        if (!found) return false;
    }
    return acceptStates.count(currentState) > 0;
}

void DFA::generateDot(const string& filename) {
    ofstream dotFile(filename);
    if (!dotFile.is_open()) {
        cerr << "�޷����ļ�: " << filename << endl;
        return;
    }
    dotFile << "digraph DFA {" << endl;
    dotFile << "    rankdir=LR;" << endl;
    dotFile << "    size=\"8,5\";" << endl;

    // ���� "start" �ڵ㣬��ʾDFA����ʼλ��
    if (!startStates.empty()) {
        dotFile << "    \"start\" [shape=plaintext];" << endl;  // start �ڵ㣬��ʾ��ʼλ��
        for (auto s : startStates) {
            dotFile << "    \"start\" -> \"" << s << "\";" << endl;  // �� start ����ʼ״̬�ļ�ͷ
        }
    }

    // ��������״̬
    for (auto s : acceptStates) {
        dotFile << "    \"" << s << "\" [shape=doublecircle, style=bold, color=green];" << endl;  // ��ǽ���״̬Ϊ˫ԲȦ
    }

    // �����յ�״̬��������ڣ�
    if (!acceptStates.empty()) {
        // �յ�״̬��˫ԲȦ���
        for (auto s : acceptStates) {
            dotFile << "    \"" << s << "\" [shape=doublecircle, style=bold, color=green];" << endl;
        }
    }

    // ������ͨ״̬
    for (auto s : stateSet) {
        if (startStates.count(s.first) == 0 && acceptStates.count(s.first) == 0) {
            dotFile << "    \"" << s.first << "\" [shape=circle];" << endl;  // ��ͨ״̬���ΪԲ��
        }
    }

    // ���״̬���ת����
    for (auto& [from, transitions] : newEdge) {
        for (auto& [to, symbol] : transitions) {
            dotFile << "    \"" << from << "\" -> \"" << to << "\" [label=\"" << symbol << "\"];" << endl;
        }
    }

    dotFile << "}" << endl;
    dotFile.close();

    cout  << filename << "generate success! " <<  endl;
}



#endif
